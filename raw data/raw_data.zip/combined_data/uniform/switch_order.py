import pandas as pd
import os


data=[]
with open('orin_code_train_uniform_not_arranged.csv', 'r',encoding='utf-8') as file:
    for line in file:
        line = line.rstrip()
        items = line.split(",")
        data.append(items)

tinyllama_more=data[0:1000]
tinyllama_less=data[5000:6000]

internlm_more=data[6000:7000]
internlm_less=data[4000:5000]

qwen1p5_more=data[3000:4000]
qwen1p5_less=data[7000:8000]

qwen0p5_more=data[1000:2000]
qwen0p5_less=data[2000:3000]

re_arranged_data=tinyllama_more+tinyllama_less+internlm_more+internlm_less+qwen1p5_more+qwen1p5_less+qwen0p5_more+qwen0p5_less
df = pd.DataFrame(re_arranged_data)
df.to_csv('orin_code_train_uniform.csv', index=False, header=False)