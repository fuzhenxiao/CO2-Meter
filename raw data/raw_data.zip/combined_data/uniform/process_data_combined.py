import pandas as pd
import os


gooddata=[]
bad_count=0

#[code,conv,prefill,decode]

for filename in os.listdir('./'):
    if '.py' in filename:
        continue 
    if 'arranged' in filename:
        continue 
    if 'final' in filename:
        continue 
    if 'code' in filename:
        tasktype=[1,0]
    else:
        tasktype=[0,1]
    data = []
    with open(filename, 'r',encoding='utf-8') as file:
        for line in file:
            line = line.rstrip()
            items = line.split(",")   #code, conv,prefill, decoding,
            #print(filename,items)
            if items[12]=='1':
                phase=[1,0]
            else:
                phase=[0,1]
            items=tasktype+phase+items
            data.append(items)
        for i in range(0,len(data)):
            if data[i][-3]!='1':
                delta_t=float(data[i][-2])-float(data[i+1000][-2])
                delta_e=float(data[i][-1])-float(data[i+1000][-1])
                #print(data)

                if data[i][6]!=data[i+1000][6] or data[i][-4]!=data[i+1000][-4]:
                    print('zhendeshaluan',data[i][6],data[i][-4],data[i+1000][6],data[i+1000][-4])

                if delta_t<0:
                    #print('No!!!',i)
                    bad_count+=1
                elif delta_e<0:
                    #print('No!!!',i)
                    bad_count+=1
                else:
                    #print(f'{data[i][-4]}, {data[i][-3]}:{float(data[i][-2]):.3f},{float(data[i][-1]):.3f}')
                    #print(f'{data[i+1000][-4]}, {data[i+1000][-3]}:{float(data[i+1000][-2]):.3f},{float(data[i+1000][-1]):.3f}')
                    #print(f'{delta_t},{delta_e}')
                    #print('================')
                    good_items=data[i]
                    good_items[-1]=delta_e
                    good_items[-2]=delta_t
                    gooddata.append(good_items)
            else:
                good_items=data[i]
                gooddata.append(good_items)

print(bad_count,len(gooddata))


df = pd.DataFrame(gooddata)
df.to_csv('train_uniform_final.csv', index=False, header=False)