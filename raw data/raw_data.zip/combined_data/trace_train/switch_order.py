import pandas as pd
import os


data=[]
with open('orin_conv_train_trace_not_arranged.csv', 'r',encoding='utf-8') as file:
    for line in file:
        line = line.rstrip()
        items = line.split(",")
        data.append(items)

tinyllama_more=data[7000:8000]
tinyllama_less=data[0:1000]

internlm_more=data[4000:5000]
internlm_less=data[3000:4000]

qwen1p5_more=data[1000:2000]
qwen1p5_less=data[6000:7000]

qwen0p5_more=data[5000:6000]
qwen0p5_less=data[2000:3000]

re_arranged_data=tinyllama_more+tinyllama_less+internlm_more+internlm_less+qwen1p5_more+qwen1p5_less+qwen0p5_more+qwen0p5_less
df = pd.DataFrame(re_arranged_data)
df.to_csv('orin_conv_train_trace.csv', index=False, header=False)